import base64
import ctypes
import os
dataset = open("base_data.csv", "r")
outputFolder = "output"



def get_raw_data():
    num = 0
    
    for x in dataset:
        num = num + 1
        filePath = "output/OutputFile_"+str(num)+".txt"
        cleanline = ""
        lineEnd = x[len(x)-10:len(x)].strip()
        lineStart = x[0:8].strip()

        #Notify for any bad data or if data already exists. 
        if os.path.isfile(filePath):
            ctypes.windll.user32.MessageBoxW(0, "Records already Exist, please remove!", "Data Exists", 0)
            exit()
        elif lineEnd != "</Binary>" and lineStart == "<Binary>":
            ctypes.windll.user32.MessageBoxW(0, "The data is not consistent on line " + str(num), "Bad Data", 0)
            break
        elif lineEnd == "</Binary>":
            lineCleaned = x[8:len(x)-10]
            
        else:
            lineCleaned = x[0:len(x)]
            
        lineCleaned = base64.b64decode(lineCleaned)
        

        #write each line to a new file
        filewrite = open("output/OutputFile_"+str(num)+".txt", "x")
        filewrite.write(str(lineCleaned))
        filewrite.close()
        


def setup():
    if not os.path.isdir(outputFolder):
        os.makedirs(outputFolder)
        

    


    
setup()
get_raw_data()
dataset.close()
ctypes.windll.user32.MessageBoxW(0, "Conversion completed", "Complete", 0)
exit()
