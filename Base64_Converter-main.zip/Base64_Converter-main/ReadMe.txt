READ ME!
* Name the input file base_data.csv
* Each new line of data must be on a new line in the input file. 
* If the output folder Exists make sure it is empty. 
* Each line of data will be exported as a separate file. 
